import R from "../raphaelContainer.js";
import drawLineFromTo  from "./drawLineFromTo.js";
import moveEffects  from "./moveEffects.js";
import GlobalStorage from '../storage';
import csInterface from '../csInterface';

//Custom Raphael function which one properly handles dragging of Sets and handle all processes have binded with it
Snap.plugin((Snap, Element, Paper, global)=>{
  Snap.Set.prototype.draggableSet = function (setObj,type) {

    var thisSet = this;
//console.log(thisSet);
    //let bbox=this[0].getBBox();
    //console.log('bboxGROUP');
    //console.log(bbox);
    //this.curenLineLocal;
    var moveFnc = function (dx, dy) {

      var _this = this;

      if (this.node.nodeName!= 'circle')
      {
        thisSet.forEach((item)=>{//sort out elements in group
          if(type=="effects"){

            EffectMove(item,this, dx, dy);//handle draging of effects
          }
          else if(type=="commonControls"){

            CommonControlsMove(item,this, dx, dy);//handle draging of commonControls
          }
        });
    }
    else {
        thisSet.forEach(function (item, i) {
          if(item!==undefined&&item.node!==null&&item.node.nodeName=="path"){
            new drawLineFromTo().moveLine(_this,dx,dy);
          }
          else if(item!==undefined&&item.node===null){
            thisSet.splice(i,1);

          }
        });
      }
    },
    startFnc = function startFnc() {

        let thisGroupCoord=thisSet[0].getBBox();//get object with central points of this group

      if (event.target.nodeName!= 'circle')
      {
        this.ox = thisGroupCoord.x;// get central point of this group (X coord)
        this.oy = thisGroupCoord.y;// get central point of this group (Y coord)
      }
      else {
        console.log(thisSet[0][3]);
        new drawLineFromTo().startdrawLineFromTo(thisSet[0][3],thisSet);
      }

    }, endFnc = function endFnc() {

                moveEffects (thisSet);

      new drawLineFromTo().endDrawLine(thisSet[0][3],thisSet);

    };

    this.forEach((elem)=>{
      console.log(elem);
      elem.drag(moveFnc, startFnc, endFnc);
    })

//this.drag(moveFnc, startFnc, endFnc);


  };
  /**/

  function EffectMove (item,_this, dx, dy){

      if (item.node.nodeName == 'circle') {
        item.attr({ cx: _this.ox + dx+1, cy: _this.oy + dy+16 });
      }
      else if (item.node.nodeName == 'rect'){
        item.attr({ x: _this.ox + dx, y: _this.oy + dy });
      }
      else if (item.node.nodeName == 'text') {
        item.attr({ x: _this.ox + dx+60, y: _this.oy + dy+15 });
      }
      else if (item.node.nodeName == 'path') {

        /*let MX=item.attr().path[0][1];
        let MY=item.attr().path[0][2];
        item.attr("path",`M${MX} ${MY}L${_this.ox+ dx} ${_this.oy+ dy+15}`);*/

      }
  }

  function CommonControlsMove(item, _this, dx, dy){
  console.log(item);
    if (item.node.nodeName == 'circle') {
         if(item.node.circleName=="circleLeft"){

           item.attr({ cx: _this.ox + dx+1, cy: _this.oy + dy+16 });
         }
         else if(item.node.circleName=="circleRight"){

           item.attr({ cx: _this.ox + dx+120, cy: _this.oy + dy+16 });
         }
       }
       else if (item.node.nodeName == 'rect'){
         item.attr({ x: _this.ox + dx, y: _this.oy + dy });
       }
       else if (item.node.nodeName == 'text') {
         item.attr({ x: _this.ox + dx+60, y: _this.oy + dy+15 });
       }
       else if (item.node.nodeName == 'path') {
         if(item.node.lineFromCyrcle=="circleRight")//moving line from right circle of common control  to Effect Block
         {
           let LX=item.attr().path[1][1];
           let LY=item.attr().path[1][2];
           item.attr("path",`M${_this.ox+ dx+120} ${_this.oy+ dy+16}L${LX} ${LY}`);
         }
         else if(item.node.lineFromCyrcle=="noCircleDistributor")//moving line from RootDistributorBlock  to common control
         {
           let MX=item.attr().path[0][1];
           let MY=item.attr().path[0][2];
           item.attr("path",`M${MX} ${MY}L${_this.ox+ dx} ${_this.oy+ dy+15}`);
         }


       }

  }

  function DistributorRootMove (item, i, _this, dx, dy){
  /*console.log(_this);*/
      if (item.node.nodeName == 'circle') {
        item.attr({ cx: _this.ox + dx+1, cy: _this.oy + dy+16 });
      }
      else if (item.node.nodeName == 'rect'){
        item.attr({ x: _this.ox + dx, y: _this.oy + dy });
      }
      else if (item.node.nodeName == 'text') {
        item.attr({ x: _this.ox + dx+80, y: _this.oy + dy+32 });
      }
      else if (item.node.nodeName == 'path'&&!item.DistributorEffects) {//moving line from this RootDistributorBlock  to common control
        let LX=item.attr().path[1][1];
        let LY=item.attr().path[1][2];
        item.attr("path",`M${_this.ox+ dx+160} ${_this.oy+ dy+32}L${LX} ${LY}`);


      }
      else if(item.node.nodeName == 'path'&&item.DistributorEffects){
        let MX=item.attr().path[0][1];
        let MY=item.attr().path[0][2];
        item.attr("path",`M${MX} ${MY}L${_this.ox+ dx+160} ${_this.oy+ dy+32}`);

      }
  }
});
