﻿// GLOBAL VARIABLES
var currentLayer={};
var effectNameArr=[];
var currentComp;
var itemWidth;

// FUNCTIONS USED AS INTERNAL IN THIS  PROJECT
function addPOIFunction(effectName, propName){
    var itemHalfWidth=  "[100," + itemWidth / 2 + "]";
    
    //defValuePOI=currentLayer.effect.property(effectName).property(propName).value;
    //currentLayer.effect.property(effectName).selected=true;
    //currentLayer.effect("Point Control").point.value
     //currentLayer.effect.property(effectName).property(propName).setValue([100,980]);
     currentLayer.effect.property(effectName).property(propName).expression=itemHalfWidth;
    
};

function addFOVFunction(effectName, propName){
    //defValueFOI=currentLayer.effect.property(effectName).property(propName).value;
    
    currentLayer.effect.property(effectName).property(propName).expression= "[index*30]";
  
};

function addWavesFunction(effectName, propName){
    currentLayer.effect.property(effectName).property("Amplitude").expression= "[300]";
    currentLayer.effect.property(effectName).property("Wavelength").expression= "[300]";
    currentLayer.effect.property(effectName).property("Phase").expression= "[50]";
    currentLayer.effect.property(effectName).property("Max Latitude").expression= "[50]";
    currentLayer.effect.property(effectName).property("Displacement").expression= "[50]";
};

function generatorPOI() {
    var F1 = function() {
       return (((1+Math.random())*0x100)|0);
    };
    var F2 = function() {
       return (((1+Math.random())*0x200)|0);
    };
    return ("["+F1()+"," + F2() + "]");
}

//MAIN CODE
$._ext = {    
    CheckCommonContrlAbility:function(effectName){
        var currentComp = app.project.activeItem;
         
        if (currentComp){
             var layerCount = currentComp.numLayers;
            if (layerCount > 0){
                for (var i = 1; i <= layerCount; ++i){
                    var currentLayer = currentComp.layers[i];
                    if(currentLayer instanceof AVLayer&&currentLayer.Effects.canAddProperty(effectName)){
                       //$.writeln(effectName);
                        //$.writeln(currentLayer.Effects.canAddProperty(effectName));

                          }
                    }
                }
            }
        },
    applyEffect : function(effectName)
    {
        currentComp = app.project.activeItem;
        itemWidth= app.project.activeItem.width;
         
        if (currentComp){
            var layerCount = currentComp.numLayers;
            if (layerCount > 0){
                for (var i = 1; i <= layerCount; ++i){

                    if(currentComp.layer(i).selected&&currentComp.layer(i) instanceof AVLayer){
                        currentLayer= currentComp.layer(i);
                        var layerEffect=currentComp.layer(i).Effects.addProperty(effectName);
                        // var layerEffectPoint=currentComp.layer(i).Effects.addProperty("Point Control");
                         //currentComp.effect("Point Control").point.value;
                         /*$.writeln(layerEffect.propertyIndex);*/
                         /*$.writeln(currentLayer.lselectedProperties);*/
                        /*for(var ty=0; ty<currentLayer.length;  ty++){
                            $.writeln(currentLayer.lselectedProperties);
                            }*/
                          
                          return layerEffect.name;
                        /*alert(currentComp.layer(i))*/
                        }
                    }

                }
            else{
                alert("Please add a layer");
                }
            }
    },
    applyEffectDistributor: function(effectName){
        
        currentComp = app.project.activeItem;
        itemWidth= app.project.activeItem.width;
         
        if (currentComp){
            var layerCount = currentComp.numLayers;
            if (layerCount > 0){
                for (var i = 1; i <= layerCount; ++i){

                    if(currentComp.layer(i).selected&&currentComp.layer(i) instanceof AVLayer){
                        currentLayer= currentComp.layer(i);
                        var layerEffect=currentComp.layer(i).Effects.addProperty(effectName);
                       layerEffect.property("Point of Interest").expression=generatorPOI();
                        
                         /*$.writeln(layerEffect.propertyIndex);*/
                         /*$.writeln(currentLayer.lselectedProperties);*/
                        /*for(var ty=0; ty<currentLayer.length;  ty++){
                            $.writeln(currentLayer.lselectedProperties);
                            }*/
                          
                          return layerEffect.name;
                        /*alert(currentComp.layer(i))*/
                        }
                    }

                }
            else{
                alert("Please add a layer");
                }
            }
        
     },
    addCommonControls: function(effectName,propName)
   {       
       
               switch (propName) {
                          case "Point of Interest":
                            addPOIFunction(effectName, propName);
                            break;
                          case "FOV":
                            addFOVFunction(effectName, propName);
                            break;
                          case "Waves":
                            addWavesFunction(effectName, propName);
                            break;
                          default:
                            alert( "Unrecognized control type" );                           
                            
                            }
               
      
       
        
    },
    moveEffectIndex: function(effectName,number)
    {
        //$.writeln(effectName);
        //$.writeln(number);
        
        var number=(number*1);
        if(number>0&&effectName)
        {
            currentLayer.effect.property(effectName).moveTo(number);
            return number;
        }
     },
 
    deleteEffect: function (effectName){
        if(effectName!=null){
            currentLayer.effect.property(effectName).remove();
         //$.writeln(effectName);
         return effectName;
            }
         
      },
  
    deleteCommonControl: function(propName, arrayOfLinkedEffects){        
        effectNameArr = arrayOfLinkedEffects.split(';');        
        //matchName
         if(effectNameArr[0]!=''){
              for (var i =0; i<effectNameArr.length; i++){            
             //currentLayer.effect.property(effectNameArr[i]).property(propName).setValue(defValuePOI); 
            
             currentLayer.effect.property(effectNameArr[i]).property(propName).expressionEnabled = false;
            }
         }        
    },
    selectEffect: function(effectName){
        currentLayer.effect.property(effectName).selected=true;
        }
};

