let csInterface = new CSInterface();

export default csInterface;
