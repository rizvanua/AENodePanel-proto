const arrButton=[{name:'Effects', systName:'effects'},{name:'Common Controls', systName:'commonControls'},{name:'Distributor', systName:'distributor'},{name:'Presets', systName:'presets'}]; //Array with buttons

export  default arrButton;
