//const R = Raphael("container", '100%', '100%' );
const R = Snap("#svg");

export default  R;
