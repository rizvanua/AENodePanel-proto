import R from "../raphaelContainer.js";
import csInterface from "../csInterface.js";
import draggableSet from "../helperFunctions/draggableSet.js";
import drawLineFromTo  from "../helperFunctions/drawLineFromTo.js";
/*import deleteFunctions from "../helperFunctions/deleteFunctions.js"*/
//import deleteInOneClick from "../helperFunctions/deleteInOneClick.js"
import activeBlockFunctionsClass from '../helperFunctions/activeBlockFunction';
import GlobalStorage from '../storage';

// This class works with mainBlocks (Effects, commonControls, Distributor) and add eventListebers (click,mouseover etc) to them

class mainBlock{
  constructor(){

  }
  createBlockEffects(x,y,item,obj){
    //console.log("BOOOOOO");
    //let objectEffect=JSON.parse(obj);
    let blockEffectName=obj.name;
    let workBlockSet=Snap.set();
    let typeNode="effects";
    workBlockSet.setEffectName=blockEffectName;
    workBlockSet.baseEffect=item.name;
    workBlockSet.point=obj.point;
    workBlockSet.angle=obj.angle;
    workBlockSet.slider=obj.slider;
    /*workBlockSet.poi=item.poi;
    workBlockSet.fov=item.fov;
    workBlockSet.strength=item.strength;
    workBlockSet.waves=item.waves;*/
    let dummy=R.rect(x,y, 120, 32,5)
    .attr({   fill: "rgb(64, 64, 64)",
              "fill-opacity":0,
              stroke: "none",
              opacity: 1,
              cursor: "pointer"
          });
            dummy.node.effectName=blockEffectName;
            //workBlockSet.push(dummy);

          GlobalStorage.lastEffectBlock.y=y+32;
    let workBlock=R.rect(x,y, 120, 32,5)
    .attr({   fill: "rgb(64, 64, 64)",
              stroke: "none",
              class:''
          });
    let title= R.text(x+60, y+16, blockEffectName)
    .attr({
            fontSize: 15,
            textAnchor: "middle",
            alignmentBaseline:"middle"
          });

                //title.node.effectName=blockEffectName;
                //workBlockSet.push(title);

          //workBlock.node.effectName=blockEffectName;
          let group=R.g(workBlock, title, dummy);
          workBlockSet.push(group);
          //dummy.toFront();


    /*let circleLeft=R.circle(x+1, y+15, 6);// If you need left circle for this block uncomment it
          circleLeft.node.effectName=item.name;
          circleLeft.node.circleName="circleLeft";
          workBlockSet.push(circleLeft);*/

          let toType = function(obj) {
            return ({}).toString.call(obj).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
          };




    GlobalStorage.historyOfObjects[blockEffectName]=workBlockSet;
    //console.log(GlobalStorage.historyOfObjects);
    workBlockSet.draggableSet(workBlockSet,typeNode);
    group.click(()=>{new activeBlockFunctionsClass().activeEffectBlock(workBlockSet,blockEffectName);});



    group.mouseover(function(){
      GlobalStorage.toDelete=workBlockSet;
      //console.log(GlobalStorage.currentLine);
      //console.log("OVER");
      //console.log(workBlockSet);
      //console.log(this);
        //workBlockSet.deleteInOneClick(workBlockSet);
    if (GlobalStorage.currentLine){
      let typeOfControll=GlobalStorage.currentLine.node.shortControlName;


          if(GlobalStorage.currentLine&&workBlockSet[typeOfControll]===false){

            workBlockSet.attr({cursor: "no-drop"});
          }
          else{
            workBlockSet.attr({cursor: "move"});
          }
        }

      GlobalStorage.overMouseSet=workBlockSet;//Push this set into temporary object for compere reasone
    });
  group.mouseout(function(){
      //console.log("OUT");
        GlobalStorage.toDelete=undefined;
        workBlockSet.attr({cursor: "move"})
        GlobalStorage.overMouseSet=null;//Clear interim object if mouse get out
    });
    return workBlockSet;
  }

  createBlockCommonControls(x,y,item,distributor,res){

    let thisItemName=res;
  /*  if(res){
      let index=res.length-1;

      let number=res.charAt(index)*1;
      if (number){
      thisItemName=`${item.name} ${number}`;
      }
    }*/


    let workBlockSet=Snap.set();
    let typeNode="commonControls";
    let dummy=R.rect(x,y, 120, 32,5)
    .attr({   fill: "rgb(64, 64, 64)",
              "fill-opacity":0,
              stroke: "none",
              opacity: 1,
              cursor: "pointer"
          });
          //workBlockSet.push(dummy);
          //dummy.node.effectName=item.effectName;

          let workBlock=R.rect(x,y, 120, 32,5)
          .attr({   //fill: "rgb(64, 64, 64)",
                    stroke: "none",
                    cursor: "move",
                    class:"commonControl"
                });
          //workBlock.node.effectName=item.effectName;

    let title= R.text(x+60, y+16, thisItemName)
    .attr({
      fontSize: 15,
      textAnchor: "middle",
      alignmentBaseline:"middle"
    });

          //title.node.effectName=item.effectName;


          //console.log(item);
          workBlockSet.shortName=item.shortName;
          workBlockSet.currentName=thisItemName;
          //workBlockSet.push(workBlock);



          //dummy.toFront();

    /*let circleLeft=R.circle(x+1, y+15, 6);// Uncomment if you need Left circle
          circleLeft.node.effectName=item.name;
          workBlockSet.push(circleLeft);
          circleLeft.node.circleName="circleLeft";*/

        //if(distributor==false){
          let circleRight=R.circle(x+120, y+15, 6);
                circleRight.node.effectName=item.name;
                //workBlockSet.push(circleRight);
                circleRight.node.circleName="circleRight";
        //}
        let group=R.g(workBlock, title, dummy,circleRight);
        workBlockSet.push(group);
    GlobalStorage.historyOfObjects[res]=workBlockSet;
    workBlockSet.fullCommonContrlName=item.fullname;
    workBlockSet.thisCommonContrlName=res;
    group.click(()=>{new activeBlockFunctionsClass().activeNotEffectBlock(workBlockSet);});
    workBlockSet.draggableSet(workBlockSet,typeNode);
    group.mouseover(function(){
      GlobalStorage.toDelete=workBlockSet;
    });
      group.mouseout(function(){
        GlobalStorage.toDelete=undefined;
      });
    return workBlockSet;

  }
  createBlockMaster(x,y,item,distributor,res){

    let thisItemName=res;
  /*  if(res){
      let index=res.length-1;

      let number=res.charAt(index)*1;
      if (number){
      thisItemName=`${item.name} ${number}`;
      }
    }*/


    let workBlockSet=Snap.set();
    let typeNode="commonControls";
    let dummy=R.rect(x,y, 120, 32,5)
    .attr({
              "fill-opacity":0,
              stroke: "none",
              opacity: 1,
              cursor: "pointer"
          });
          //workBlockSet.push(dummy);
          //dummy.node.effectName=item.effectName;

          let workBlock=R.rect(x,y, 120, 32,5)
          .attr({   //fill: "rgb(64, 64, 64)",
                    stroke: "none",
                    class:"multiplier"
                });
          //workBlock.node.effectName=item.effectName;

    let title= R.text(x+60, y+15, thisItemName)
    .attr({
      fontSize: 15,
      textAnchor: "middle",
      alignmentBaseline:"middle"
    });

          //title.node.effectName=item.effectName;


          //console.log(item);
          workBlockSet.shortName=item.shortName;
          workBlockSet.currentName=thisItemName;
          //workBlockSet.push(workBlock);
          //workBlockSet.push(title);
          let group=R.g(workBlock, title, dummy);
          workBlockSet.push(group);

          //dummy.toFront();

    /*let circleLeft=R.circle(x+1, y+15, 6);// Uncomment if you need Left circle
          circleLeft.node.effectName=item.name;
          workBlockSet.push(circleLeft);
          circleLeft.node.circleName="circleLeft";*/

        /*if(distributor==false){
          let circleRight=R.circle(x+120, y+15, 6);
                circleRight.node.effectName=item.name;
                workBlockSet.push(circleRight);
                circleRight.node.circleName="circleRight";
        }*/

    GlobalStorage.historyOfObjects[res]=workBlockSet;
    workBlockSet.fullCommonContrlName=item.fullname;
    workBlockSet.thisCommonContrlName=res;
    group.click(()=>{new activeBlockFunctionsClass().activeNotEffectBlock(workBlockSet);});
    workBlockSet.draggableSet(workBlockSet,typeNode);
    group.mouseover(function(){
      GlobalStorage.toDelete=workBlockSet;
    });
      group.mouseout(function(){
        GlobalStorage.toDelete=undefined;
      });
    return workBlockSet;

  }


}

 export  default mainBlock;
