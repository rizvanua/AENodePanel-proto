import csInterface from "../csInterface.js";

function CheckCommonContrlAbility(item){
  /*csInterface.evalScript(`$._ext.CheckCommonContrlAbility("${item.name}")`,(res)=>{
    //console.log(res);

  });*/
}

export default CheckCommonContrlAbility;
